#pragma once

//- Number of conservative variables
static const int PhysDim = 5;

//- Number of basis functions
static const int nShapes = 3;

//- Initialisaton of tools for computations
void Initialize() {}
