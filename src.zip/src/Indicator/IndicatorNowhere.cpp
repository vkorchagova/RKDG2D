#include "IndicatorNowhere.h"

using namespace std;

vector<int> IndicatorNowhere::checkDiscontinuities() const
{
    return {};
}
