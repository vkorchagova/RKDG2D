#include "Indicator.h"
#include <fstream>

using namespace std;

Indicator::Indicator(const Mesh& msh, const Physics& prb) : mesh(msh), problem(prb)
{

}


                                                
